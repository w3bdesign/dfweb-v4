import { Github, ExternalLink } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const projects = [
  {
    title: "Earth Doom",
    description:
      "Fullstack strategispill utviklet i Next.js med PostgreSQL og Typescript. Inspirert av Planetarion. Inkluderer innlogging, database, grafer, responsivt design med mer.",
    technologies: ["Next.js", "Typescript", "Tailwind", "Prisma", "Clerk", "tRPC", "PostgreSQL", "Chart.js"],
    github: "https://github.com/w3bdesign/earthdoom",
    live: "https://www.earthdoom.com",
    featured: true,
  },
  {
    title: "Frisørsalong Bookingsystem",
    description:
      "Fullstack bookingsystem for frisørsalonger med NestJS og Vue 3. Statusvisning for TV. Bestilling av klipp med automatisk tilgjengelighetssjekk. Administrasjonspanel for booking- og ansatthåndtering.",
    technologies: ["NestJS", "Vue 3", "TypeScript", "PostgreSQL", "JWT", "TypeORM", "Tailwind CSS", "Docker"],
    github: "https://github.com/w3bdesign/frisorsalong-booking",
    live: null,
    featured: true,
  },
  {
    title: "NextJS WooCommerce",
    description:
      "Nettbutikk med Next.js og WooCommerce som backend. Produktene hentes via GraphQL. Produktsøk via Algolia og egenutviklet plugin. Formvalidering gjøres via native HTML5.",
    technologies: ["Typescript", "Next.js", "Algolia", "Tailwind", "React Hook Form"],
    github: "https://github.com/w3bdesign/nextjs-woocommerce",
    live: "https://next-woocommerce.dfweb.no",
    featured: true,
  },
  {
    title: "LO - Partiene Svarer",
    description:
      "Valgomat for LO. Frontend er lagd i Vue 2. Styling via SCSS. Backend er hentet fra CMS-løsningen til LO i Episerver.",
    technologies: ["Vue 2", "SCSS", "Episerver"],
    github: null,
    live: "https://www.lo.no/hva-vi-gjor/partiene-svarer-2021",
    featured: false,
  },
  {
    title: "Dfweb versjon 4",
    description:
      "Matrix-inspirert portefølje utviklet med Next.js og Typescript. Animasjoner via Framer Motion. Design med Tailwind CSS. Form med React Hook Form. Data hentes fra Sanity.",
    technologies: ["Next.js", "Typescript", "Sanity", "Framer Motion", "Tailwind"],
    github: "https://github.com/w3bdesign/dfweb-v4",
    live: "https://www.dfweb.no",
    featured: false,
  },
  {
    title: "WP Algolia Woo Indexer",
    description:
      "Plugin for å sende WooCommerce-produkter til Algolia. Pluginen er kodet i PHP 8 og inkluderer oversettelser via .PO og .MO filer. Koden er testet i PHPCS.",
    technologies: ["WordPress", "PHP", "OOP", "PHPCS", "POT"],
    github: "https://github.com/w3bdesign/wp-algolia-woo-indexer",
    live: null,
    featured: false,
  },
  {
    title: "NuxtJS WooCommerce",
    description:
      "Nettbutikk med Nuxt 3 og Vue 3. Produktene hentes fra WooCommerce. Søk via egenutviklet Algolia plugin. Formvalidering via Formkit, Vee Validate og Yup.",
    technologies: ["Vue 3", "Nuxt 3", "Tailwind", "Formkit", "Algolia"],
    github: "https://github.com/w3bdesign/nuxtjs-woocommerce",
    live: "https://nuxt.dfweb.no",
    featured: false,
  },
  {
    title: "Laravel Vue Ecommerce",
    description:
      "Nettbutikk med Laravel 10 og Vue 3. Formhåndtering med Formkit. Statehåndtering via Pinia. Stripe for betaling. Innebygd Laravel søk. PostgreSQL database.",
    technologies: ["Laravel", "Vue 3", "Formkit", "Pinia", "Stripe", "PostgreSQL"],
    github: "https://github.com/w3bdesign/laravel-vue-ecommerce",
    live: null,
    featured: false,
  },
]

export function ProjectsSection() {
  const featuredProjects = projects.filter((p) => p.featured)
  const otherProjects = projects.filter((p) => !p.featured)

  return (
    <section id="projects" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-[200px_1fr] gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-primary" />
              <h2 className="text-sm font-mono text-primary uppercase tracking-wider">Prosjekter</h2>
            </div>
          </div>

          <div className="space-y-16">
            {/* Featured Projects */}
            <div className="space-y-12">
              {featuredProjects.map((project, index) => (
                <div
                  key={index}
                  className="group p-6 rounded-lg bg-card border border-border hover:border-primary/50 transition-colors"
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-sm font-mono text-primary mb-2">Fremhevet Prosjekt</p>
                        <h3 className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors">
                          {project.title}
                        </h3>
                      </div>
                      <div className="flex gap-3">
                        {project.github && (
                          <a
                            href={project.github}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-foreground transition-colors"
                            aria-label="Se kildekode på GitHub"
                          >
                            <Github className="h-5 w-5" />
                          </a>
                        )}
                        {project.live && (
                          <a
                            href={project.live}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-foreground transition-colors"
                            aria-label="Se live prosjekt"
                          >
                            <ExternalLink className="h-5 w-5" />
                          </a>
                        )}
                      </div>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech) => (
                        <Badge
                          key={tech}
                          variant="secondary"
                          className="bg-primary/10 text-primary hover:bg-primary/20 border-0"
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Other Projects Grid */}
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-8">Andre Prosjekter</h3>
              <div className="grid md:grid-cols-2 gap-6">
                {otherProjects.map((project, index) => (
                  <div
                    key={index}
                    className="group p-6 rounded-lg bg-card border border-border hover:border-primary/50 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-6 w-6 text-primary"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={1.5}
                            d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
                          />
                        </svg>
                      </div>
                      <div className="flex gap-3">
                        {project.github && (
                          <a
                            href={project.github}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-foreground transition-colors"
                            aria-label="Se kildekode på GitHub"
                          >
                            <Github className="h-5 w-5" />
                          </a>
                        )}
                        {project.live && (
                          <a
                            href={project.live}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-foreground transition-colors"
                            aria-label="Se live prosjekt"
                          >
                            <ExternalLink className="h-5 w-5" />
                          </a>
                        )}
                      </div>
                    </div>
                    <h4 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors mb-2">
                      {project.title}
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.slice(0, 5).map((tech) => (
                        <span key={tech} className="text-xs text-muted-foreground font-mono">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-center pt-8">
              <p className="text-muted-foreground mb-4">
                På{" "}
                <a
                  href="https://github.com/w3bdesign"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline underline-offset-4"
                >
                  GITHUB
                </a>{" "}
                kan du se flere eksempler på arbeid jeg har gjort.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
