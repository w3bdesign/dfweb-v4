const skillCategories = [
  {
    title: "Frontend",
    skills: [
      "React",
      "Vue 2/3",
      "Next.js",
      "Nuxt",
      "Gatsby",
      "SvelteKit",
      "TypeScript",
      "JavaScript (ES6+)",
      "HTML5",
      "CSS3",
      "Tailwind CSS",
      "SCSS/SASS",
      "Bootstrap",
    ],
  },
  {
    title: "Backend & CMS",
    skills: [
      "Node.js",
      "PHP",
      "Python",
      "Laravel",
      "WordPress",
      "WooCommerce",
      "Sanity.io",
      "MySQL",
      "PostgreSQL",
      "GraphQL",
      "REST APIs",
    ],
  },
  {
    title: "Testing & DevOps",
    skills: [
      "Jest",
      "Playwright",
      "Cypress",
      "Storybook",
      "Docker",
      "Git",
      "GitHub Actions",
      "CI/CD",
      "Vercel",
      "Netlify",
      "Linux",
      "Windows 10",
    ],
  },
  {
    title: "AI & Tools",
    skills: [
      "AI Integrations",
      "OpenAI API",
      "Discord Bots",
      "Figma",
      "Adobe XD",
      "Photoshop",
      "VS Code",
      "Webpack",
      "Vite",
      "npm/yarn",
    ],
  },
]

export function SkillsSection() {
  return (
    <section id="skills" className="py-24 px-6 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-[200px_1fr] gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-primary" />
              <h2 className="text-sm font-mono text-primary uppercase tracking-wider">Kompetanse</h2>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {skillCategories.map((category) => (
              <div key={category.title} className="space-y-4">
                <h3 className="text-lg font-semibold text-foreground">{category.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1.5 text-sm bg-secondary text-secondary-foreground rounded-md border border-border hover:border-primary/50 transition-colors"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
