import { ArrowUpRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const experiences = [
  {
    period: "2011 — Nå",
    title: "Senior Frontend Utvikler",
    company: "Frilanser",
    companyUrl: "https://dfweb.no",
    description:
      "Over 10 års erfaring med utvikling og design av nettbutikker og nettsider. Erfaring både med fullstack og frontend, men i nyere tid spesialisert på frontend. 100% positive tilbakemeldinger på Fiverr.",
    technologies: ["React", "Vue 2/3", "Next.js", "Nuxt", "TypeScript", "WordPress"],
  },
  {
    period: "2021",
    title: "Frontend Utvikler",
    company: "LO Norge",
    companyUrl: "https://www.lo.no",
    description:
      "Utviklet valgomaten 'Partiene Svarer' for LO. Frontend bygget i Vue 2 med SCSS styling. Backend integrert med Episerver CMS.",
    technologies: ["Vue 2", "SCSS", "Episerver"],
  },
  {
    period: "2015 — Nå",
    title: "Open Source Contributor",
    company: "GitHub",
    companyUrl: "https://github.com/w3bdesign",
    description:
      "Aktiv bidragsyter til open-source prosjekter. Daglige commits og bidrag til utviklerfellesskapet. Prosjekter inkluderer fullstack applikasjoner, WordPress plugins og e-handelsløsninger.",
    technologies: ["Next.js", "Vue 3", "NestJS", "PostgreSQL", "Docker"],
  },
  {
    period: "Ongoing",
    title: "WordPress & WooCommerce Spesialist",
    company: "Fiverr",
    companyUrl: "https://www.fiverr.com",
    description:
      "Skreddersydde WordPress-løsninger og WooCommerce nettbutikker. Utvikling av custom plugins inkludert WP Algolia Woo Indexer for produktsøk.",
    technologies: ["WordPress", "WooCommerce", "PHP 8", "MySQL", "Algolia"],
  },
]

export function ExperienceSection() {
  return (
    <section id="experience" className="py-24 px-6 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-[200px_1fr] gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-primary" />
              <h2 className="text-sm font-mono text-primary uppercase tracking-wider">Erfaring</h2>
            </div>
          </div>

          <div className="space-y-12">
            {experiences.map((experience, index) => (
              <div
                key={index}
                className="group grid md:grid-cols-[150px_1fr] gap-4 md:gap-8 p-6 -mx-6 rounded-lg hover:bg-secondary/50 transition-colors"
              >
                <p className="text-sm text-muted-foreground font-mono">{experience.period}</p>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {experience.title} ·{" "}
                      <a
                        href={experience.companyUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 hover:underline underline-offset-4"
                      >
                        {experience.company}
                        <ArrowUpRight className="h-4 w-4" />
                      </a>
                    </h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{experience.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {experience.technologies.map((tech) => (
                      <Badge
                        key={tech}
                        variant="secondary"
                        className="bg-primary/10 text-primary hover:bg-primary/20 border-0"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
