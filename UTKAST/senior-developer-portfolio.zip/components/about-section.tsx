export function AboutSection() {
  return (
    <section id="cv" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-[200px_1fr] gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-primary" />
              <h2 className="text-sm font-mono text-primary uppercase tracking-wider">Om Meg</h2>
            </div>
          </div>

          <div className="space-y-8">
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed text-pretty">
              Totalt over <span className="text-foreground font-medium">10 års erfaring</span> med utvikling og design
              av nettbutikker og nettsider, erfaring både med fullstack og frontend, men i nyere tid{" "}
              <span className="text-foreground font-medium">spesialisert på frontend</span>.
            </p>

            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed text-pretty">
              Jeg har lang og relevant erfaring med språk som{" "}
              <span className="text-foreground font-medium">PHP, Javascript, Python og Typescript</span> med rammeverk
              som{" "}
              <span className="text-foreground font-medium">React, Gatsby, Svelte, Vue 2/3, Nuxt, Next, Node.js</span>,
              WordPress, WooCommerce og Storybook.
            </p>

            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed text-pretty">
              Testing med <span className="text-foreground font-medium">Jest, Playwright og Cypress</span> samt design
              med <span className="text-foreground font-medium">Tailwind CSS, Bootstrap, SCSS</span> og svært mange
              andre relevante verktøy og rammeverk.
            </p>

            <div className="pt-4">
              <a
                href="https://www.dfweb.no/cv2.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
              >
                Last ned CV (PDF)
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
