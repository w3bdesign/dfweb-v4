import { Mail, Github, Linkedin } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ContactSection() {
  return (
    <section id="contact" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-[200px_1fr] gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-px w-12 bg-primary" />
              <h2 className="text-sm font-mono text-primary uppercase tracking-wider">Kontakt</h2>
            </div>
          </div>

          <div className="space-y-12">
            <div className="space-y-6 max-w-2xl">
              <h3 className="text-3xl md:text-4xl font-bold text-foreground text-balance">Ta Kontakt</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Jeg er alltid interessert i nye prosjekter og muligheter. Enten du trenger en senior utvikler til teamet
                ditt eller ønsker å samarbeide om noe spennende, er innboksen min alltid åpen.
              </p>
            </div>

            <div>
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                <a href="mailto:daniel@dfweb.no">
                  <Mail className="h-4 w-4 mr-2" />
                  Si Hei
                </a>
              </Button>
            </div>

            <div className="pt-12 border-t border-border">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="flex gap-6">
                  <a
                    href="https://github.com/w3bdesign"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="GitHub"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                  <a
                    href="https://linkedin.com/in/danielfjeldstad"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                </div>

                <p className="text-sm text-muted-foreground">Bygget med Next.js & Tailwind CSS</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
