"use client"

import { useState } from "react"
import { ArrowDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { MatrixRain } from "@/components/matrix-rain"

export function HeroSection() {
  const [isMinimized, setIsMinimized] = useState(false)
  const [isMaximized, setIsMaximized] = useState(false)
  const [isClosed, setIsClosed] = useState(false)

  return (
    <section className="min-h-screen flex flex-col justify-center px-6 pt-20 relative overflow-hidden">
      <MatrixRain />

      <div className="max-w-6xl mx-auto w-full grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <div className="space-y-8">
          <div className="space-y-4">
            <p className="text-primary font-mono text-sm tracking-wider uppercase">Webutvikler</p>
            <h1 className="text-5xl md:text-7xl font-bold text-foreground tracking-tight text-balance">
              Hei! Jeg heter Daniel Fjeldstad
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed max-w-xl text-pretty">
              Jeg er en webutvikler med <span className="text-primary font-medium">over 10 års</span> erfaring. Jeg kan
              Next.js, JavaScript, TypeScript, React, Vue, PHP, WordPress og mye mer.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {["React", "VueJS", "TypeScript", "WordPress", "PHP"].map((skill) => (
              <span
                key={skill}
                className="px-4 py-2 text-sm font-medium bg-primary/10 text-primary rounded-full border border-primary/20"
              >
                {skill}
              </span>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
              <a href="#projects">Se Prosjekter</a>
            </Button>
            <Button size="lg" variant="outline" className="border-border hover:bg-secondary bg-transparent" asChild>
              <a href="#contact">Kontakt Meg</a>
            </Button>
          </div>

          <div className="flex items-center gap-8 pt-4">
            <div>
              <p className="text-3xl font-bold text-foreground">10+</p>
              <p className="text-sm text-muted-foreground">Års erfaring</p>
            </div>
            <div className="w-px h-12 bg-border" />
            <div>
              <p className="text-3xl font-bold text-foreground">100%</p>
              <p className="text-sm text-muted-foreground">Fiverr rating</p>
            </div>
            <div className="w-px h-12 bg-border" />
            <div>
              <p className="text-3xl font-bold text-foreground">#1</p>
              <p className="text-sm text-muted-foreground">på GitHub i Norge</p>
            </div>
          </div>
        </div>

        <div className="relative hidden lg:block">
          <div className="absolute inset-0 bg-primary/5 rounded-full blur-3xl" />
          <div
            className={`relative aspect-square max-w-md mx-auto transition-all duration-300 ${
              isMaximized ? "max-w-full scale-110" : ""
            } ${isClosed ? "opacity-0 scale-95 pointer-events-none" : "opacity-100"}`}
          >
            <div
              className={`absolute inset-4 rounded-2xl bg-secondary border border-border overflow-hidden transition-all duration-300 ${
                isMinimized ? "scale-y-0 origin-top" : "scale-y-100"
              }`}
            >
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <span className="text-xs text-muted-foreground font-mono">developer.ts</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setIsMinimized(!isMinimized)}
                    className="w-8 h-5 flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                    aria-label="Minimize"
                  >
                    <div className="w-2.5 h-px bg-muted-foreground" />
                  </button>
                  <button
                    onClick={() => setIsMaximized(!isMaximized)}
                    className="w-8 h-5 flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                    aria-label="Maximize"
                  >
                    <div className="w-2 h-2 border border-muted-foreground" />
                  </button>
                  <button
                    onClick={() => setIsClosed(true)}
                    className="w-8 h-5 flex items-center justify-center hover:bg-destructive/80 transition-colors group"
                    aria-label="Close"
                  >
                    <span className="text-muted-foreground group-hover:text-destructive-foreground text-xs">✕</span>
                  </button>
                </div>
              </div>
              <div className="p-8 pt-14 font-mono text-sm">
                <p className="text-muted-foreground">{"// Hello, world!"}</p>
                <p className="mt-2">
                  <span className="text-chart-2">const</span> <span className="text-foreground">developer</span>{" "}
                  <span className="text-muted-foreground">=</span> <span className="text-chart-4">{"{"}</span>
                </p>
                <p className="pl-4">
                  <span className="text-primary">name</span>
                  <span className="text-muted-foreground">:</span> <span className="text-chart-4">{'"Daniel"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-4">
                  <span className="text-primary">title</span>
                  <span className="text-muted-foreground">:</span>{" "}
                  <span className="text-chart-4">{'"Fullstack Dev"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-4">
                  <span className="text-primary">skills</span>
                  <span className="text-muted-foreground">:</span> <span className="text-chart-4">{"["}</span>
                </p>
                <p className="pl-8">
                  <span className="text-chart-4">{'"Next.js"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-8">
                  <span className="text-chart-4">{'"React"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-8">
                  <span className="text-chart-4">{'"TypeScript"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-8">
                  <span className="text-chart-4">{'"Vue"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-8">
                  <span className="text-chart-4">{'"Node.js"'}</span>
                  <span className="text-muted-foreground">,</span>
                </p>
                <p className="pl-8">
                  <span className="text-chart-4">{'"PHP"'}</span>
                </p>
                <p className="pl-4">
                  <span className="text-chart-4">{"]"}</span>
                </p>
                <p>
                  <span className="text-chart-4">{"}"}</span>
                  <span className="text-muted-foreground">;</span>
                </p>
              </div>
            </div>
          </div>
          {isClosed && (
            <button
              onClick={() => setIsClosed(false)}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-mono text-sm"
            >
              Åpne developer.ts
            </button>
          )}
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden md:block z-10">
        <a href="#projects" className="text-muted-foreground hover:text-primary transition-colors">
          <ArrowDown className="h-6 w-6" />
        </a>
      </div>
    </section>
  )
}
